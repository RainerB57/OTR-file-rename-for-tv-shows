# -*- coding: utf-8 -*-
serieslinks = {
'The Big Bang Theory' : 'the-big-bang-theory',
'The Simpsons' : 'die-simpsons',
'Marvel s Agents of S H I E L D':'the-agents-of-s-h-i-e-l-d',
'Fringe':'fringe-grenzfaelle-des-fbi',
'The Vampire Diaries':'Vampire-Diaries',
'Grey s Anatomy Die jungen Aerzte':'greys-anatomy',
'Game Of Thrones Das Lied von Eis und Feuer':'game-of-thrones', 
'Hell on Wheels USA 2014': 'hell-on-wheels', 
'Einstein': 'einstein-2015' ,
'New Tricks - Die Krimispezialisten': 'new-tricks',
'New Tricks     Die Krimispezialisten': 'new-tricks',
'This Is Us Das ist Leben':'This-Is-Us',
'Sylvia s Cats': 'Sylvias-Cats',
'Rosewood USA 2016': 'Rosewood',
'Rosewood USA 2017': 'Rosewood',
'Hooten the Lady': 'Hooten-and-the-Lady',
'Marvel s Agents of S H I E L D': 'Marvels-Agents-of-Shield',
'Once Upon A Time Es war einmal   ': 'Once-Upon-A-Time-Es-war-einmal'
}
               #to be continued...
