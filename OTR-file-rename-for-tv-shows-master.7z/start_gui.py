#!/usr/bin/python
#encoding: utf-8
#Version vom 2018-03-11 12:22

from PyQt4 import QtCore, QtGui
import sys
import os
import GUI.otr_main

GUI.otr_main.main();